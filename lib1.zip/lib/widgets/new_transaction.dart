import 'package:flutter/material.dart';

class NewTransaction extends StatelessWidget {
  final Function addNewTransation;
  final titlecontroller = TextEditingController();
  final amountcontroller = TextEditingController();
  NewTransaction(this.addNewTransation);

  void submitData() {
    final enteredTitle = titlecontroller.text;
    final enteredAmount = double.parse(amountcontroller.text);

    if ((enteredAmount <= 0) || (enteredTitle.isEmpty)) {
      return;
    }

    addNewTransation(enteredTitle, enteredAmount);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 16,
      child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'Title',
                ),
                controller: titlecontroller,
                onChanged:(_)=>print("change title "),
                
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Amount'),
                controller: amountcontroller,
                keyboardType: TextInputType.number,
                onChanged: (_)=>print("change amount"),
                
              ),
              ElevatedButton(
                onPressed: submitData,
                child: Text(
                  'Add Transaction',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              )
            ],
          )),
    );
  }
}
